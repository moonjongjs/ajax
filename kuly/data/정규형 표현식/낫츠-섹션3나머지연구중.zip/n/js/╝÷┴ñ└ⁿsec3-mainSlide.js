;(function($, window, document, undefined){
	var winW  = 0;
	var s3cnt = [];
	var s3mov = [];
	var wrapW = [];
	var slidW = 0;	
	var z     = 0;
	var n     = [];
	var sEnd  = [];
	var dTime = 600;
	var s3pag = ['.s3s0PageBt','.s3s1PageBt','.s3s2PageBt'];
	
		sec3SlideResizeFn();
		// setTimeout(sec3SlideResizeFn,100);

		$(window).resize(function(){
			sec3SlideResizeFn();
		});
	
		function sec3SlideResizeFn(){
			winW = $(window).innerWidth();
			s3mov[0] = [];
			s3mov[1] = [];
			s3mov[2] = [];
			//칸수 cols 3 2 1 
			if( winW > 760 ){
				cols=3;
				s3cnt = [0,0,0];
				s3mov[0] = [3,3];		// 6/3=2(0~1) 
				s3mov[1] = [3,2];		// 5/3=2(0~1) 
				s3mov[2] = [0,0];		// 3/3=0(0~0) 
			}
			else if( winW > 480 ){
				cols=2;	
				s3cnt = [0,0,0];
				s3mov[0] = [2,2,2]; 	// 6/2=3(0~2)
				s3mov[1] = [2,2,1.5];	// 5/2=3(0~2)
				s3mov[2] = [2,1,0];		// 3/2=2(0~1)
			}
			else {
				cols=1;
				s3cnt = [0,0,0];
				s3mov[0] = [1,1,1,1,1,1]; // 6/1=6(0~5)
				s3mov[1] = [1,1,1,1,1,0]; // 5/1=5(0~4)
				s3mov[2] = [1,1,1,0,0,0]; // 3/1=3(0~3)
			}

			
			if( winW >= 1110 ){
				slidW = 1110/cols;	
			}
			else{
				slidW = winW/cols;
			}
			
			for(i=0; i<=2; i++){
				n[i] = $('.section3-slide-wrap').eq(i).find('li').length;
				
				sEnd[i] = Math.ceil(n[i]/cols)-1;
				wrapW[i] = slidW * n[i];
				$('.section3-slide-wrap').eq(i).css({width: wrapW[i] });
			}
			
			
			
			//슬라이드wrap 너비
			$('.section3-slide-wrap>li').css({width: slidW });
			
			s3mainSlide();  //Realtime
		}




		//탭메뉴 버튼 클릭해서 
		//해당 슬라이드 보이기	
		$('.sec3TabBt').each(function(idx){
			$(this).on({
				click:	function(){
					
					z = idx; //슬라이드번호 리턴값 
					
					$('.sec3TabBt').removeClass('addS3TabDeco');
					$(this).addClass('addS3TabDeco');
					
					$('.section3-slide-container').removeClass('addSlide');
					$('.section3-slide-container').eq(idx).addClass('addSlide');
				}
			});
		});
		
		//터치 이벤트 
		$('.section3-slide-view').swipe({
			swipeLeft:	function(){
				if( !$('.sec4Slide-wrap').is(':animated') ){
					s3NextFn();	
				}
			},
			swipeRight:	function(){
				if( !$('.sec4Slide-wrap').is(':animated') ){				
					s3PrevFn();
				}
			}		
		});
		
		
		//다음 슬라이드 버튼 클릭이벤트 탭메뉴 버튼에서 슬라이드그룹 결정 z
		$('.s3NextBt').on({
			click:	function(){
				if( !$('.sec4Slide-wrap').is(':animated') ){
					s3NextFn();
				}
			}
		});	
			
		//이전 슬라이드 버튼 클릭이벤트 탭메뉴 버튼에서 슬라이드그룹 결정 z
		$('.s3PrevBt').on({
			click:	function(){
				if( !$('.sec4Slide-wrap').is(':animated') ){
					s3PrevFn();
				}
			}
		});	
			
		//다음 슬라이드 카운트 함수
		function s3NextFn(){
			s3cnt[z]++;

		
			if( s3cnt[z] > sEnd[z] ){  //6/2=3-1(칸) 0, 1
				s3cnt[z] = sEnd[z];
			}
							
			s3mainSlide();
		}	
		
		//이전 슬라이드 카운트 함수
		function s3PrevFn(){
			s3cnt[z]--;
			if( s3cnt[z] < 0 ){
				s3cnt[z]=0;
			}
			s3mainSlide();
		}	
		//페이지네이션
		function pageNationFn(){
			///.s3s0PageBt .s3s1PageBt .s3s2PageBt
			$('.sec4PageBt').removeClass('addPageEffect');
			$('.sec4PageBt').eq(s3cnt[z]).addClass('addPageEffect');
			
			// s3pag = ['.s3s0PageBt','.s3s1PageBt','.s3s2PageBt'];			
			// $( s3pag[z] ).removeClass('addPageEffect');
			// $( s3pag[z] ).eq(s3cnt[z]).addClass('addPageEffect');
		}
		
		//섹션3 슬라이드0 페이지버튼0 클릭이벤트
		$('.s3s0PageBt').each(function(index){
			$(this).on({
				click:	function(){
					z=0;  //첫번째 슬라이드그룹
					s3cnt[z]=index;
					s3mainSlide();
				}
			});
		});
		
		//섹션3 슬라이드1 페이지버튼1 클릭이벤트
		$('.s3s1PageBt').each(function(index){
			$(this).on({
				click:	function(){
					z=1;  //두번째 슬라이드그룹
					s3cnt[z]=index;
					s3mainSlide();
				}
			});
		});
		
		//섹션3 슬라이드2 페이지버튼2 클릭이벤트
		$('.s3s2PageBt').each(function(index){
			$(this).on({
				click:	function(){
					z=2;  //세번째 슬라이드그룹
					s3cnt[z]=index;
					s3mainSlide();
				}
			});
		});
		
		//슬라이드 콘테이너0 메인함수
		function s3mainSlide(){
			pageNationFn();                                                                               
			$('.section3-slide-wrap').eq(z).stop().animate({left: -(( slidW * s3mov[z][s3cnt[z]] ) * s3cnt[z] )}, dTime, 'swing'); 
		}
		
		
})(jQuery, window, document);
//sec3-mainSlide.js