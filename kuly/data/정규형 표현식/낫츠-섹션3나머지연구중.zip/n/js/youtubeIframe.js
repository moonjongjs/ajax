	
	//YouTube loading
	youtubeOnloadFn();
	function youtubeOnloadFn(){
		if (!window['YT']) {var YT = {loading: 0,loaded: 0};}if (!window['YTConfig']) {var YTConfig = {'host': 'http://www.youtube.com'};}if (!YT.loading) {YT.loading = 1;(function(){var l = [];YT.ready = function(f) {if (YT.loaded) {f();} else {l.push(f);}};window.onYTReady = function() {YT.loaded = 1;for (var i = 0; i < l.length; i++) {try {l[i]();} catch (e) {}}};YT.setConfig = function(c) {for (var k in c) {if (c.hasOwnProperty(k)) {YTConfig[k] = c[k];}}};var a = document.createElement('script');a.type = 'text/javascript';a.id = 'www-widgetapi-script';a.src = 'https://s.ytimg.com/yts/jsbin/www-widgetapi-vfl_QvS8o/www-widgetapi.js';a.async = true;var c = document.currentScript;if (c) {var n = c.nonce || c.getAttribute('nonce');if (n) {a.setAttribute('nonce', n);}}var b = document.getElementsByTagName('script')[0];b.parentNode.insertBefore(a, b);})();}
	}
	
	//YouTube 메인 함수 실행	
	window.onload = function(){	
		youtubeObj();
		
	}

		function youtubeObj(){

			var videos = $('.youtubeWrap');
			for(var i=0; i < videos.length; i++){
			var player;
			var youtube = videos[i];
			var geturl = $('.youtubeWrap').attr("data-url")
				$('.youtubeWrap iframe').attr("src",
					  "https://www.youtube.com/embed/" + geturl
					+ "?&enablejsapi=1&html5-1");
				$('.youtubeWrap iframe').attr('frameborder', 0);
				youtube.onPlayerReady = function(event){
					event.target.mute();
				}
				player = new YT.Player(youtube, {
					 playerVars: {
						'width' : '100%',
						'height' : '100%',
						'autoplay' : 1,
						'controls' : 0,
						'autohide' : 1,
						'wmode': 'opaque',
						'showinfo' : 0,
						'loop' : 1,
						'mute' : 0,
						'rel' : 0,
						'playlist' : geturl
					},
					videoId: geturl,
					events: {
						  'onReady': youtube.onPlayerReady
					}
				});
				
			}
			
					
					
			
		} //youtubeObj() 메인함수 끝

		var winW=0;
			videoResizeFn();
			setTimeout(videoResizeFn,100);
		
			$(window).resize(function(){
				videoResizeFn();
			});
			
			function videoResizeFn(){
				winW = $(window).innerWidth();
				if( winW >= 1903 ){
					winW = 1903;
				}
				else{
					winW = $(window).innerWidth();
				}
				
				$('.youtubeWrap').css({height: winW*0.562391178  });
				$('#section5>div').css({height: winW*0.562391178  });
			}		
		
		
	
	
		