;(function( $, window, document, undefined ){
	
	var winW   = 0;
	var s4cnt  = 0; 
	var s4t   = 0; 
	var setId  = 0; 
	var setId2 = 0; 
	var n = $('.sec4Slide-wrap>li').length-3;

	   //섹션4 반응형 슬라이드
		sec4SlideResizeFn();
		setTimeout(sec4SlideResizeFn,100);

		$(window).resize(function(){
			sec4SlideResizeFn();
		});

		function sec4SlideResizeFn(){
			winW = $(window).innerWidth();
				
			if( winW >= 1600 ){
				s4slideW = 1600/2;  //800
			}
			else if( winW > 760 ){
				s4slideW = winW/2;
			}	
			else{
				s4slideW = winW/1;
			}
			
			$('.sec4Slide').css({ width: s4slideW });  //기본 너비 800픽셀
			$('.sec4Slide-wrap').css({ width: s4slideW*(n+3), marginLeft:-s4slideW });  //기본 너비 800픽셀
			
			sec4MainslideFn();
		}
		
		autoPlayFn();
		
		function autoPlayFn(){
			setId = setInterval(s4NextFn, 4000);
		}
		
		
		//5초간 터치없으면 자동 실행 함수
		function touchTimeControlFn(){
			s4t=0;
			clearInterval(setId);
			clearInterval(setId2);
			setId2 = setInterval(function(){
				s4t++;
				if(s4t>5){
					s4NextFn();
					clearInterval(setId);
					autoPlayFn();
					clearInterval(setId2);  //자신의 타이머중지
				}
			},1000);
		}
		
		
		//터치 이벤트 
		$('.sec4Slide-wrap').swipe({
			swipeLeft:	function(){
				if( !$('.sec4Slide-wrap').is(':animated') ){
					s4NextFn();
					touchTimeControlFn();					
				}
			},
			swipeRight:	function(){
				if( !$('.sec4Slide-wrap').is(':animated') ){
					s4PrevFn();
					touchTimeControlFn();
				}
			}		
		});
		
		//다음 슬라이드 카운트 함수
		function s4NextFn(){
			s4cnt++;
			sec4MainslideFn()
		}	
		
		//이전 슬라이드 카운트 함수
		function s4PrevFn(){
			s4cnt--;
			sec4MainslideFn()
		}	
		
		$('.s4PageBt').each(function(index){
			$(this).on({
				click:	function(){
					s4cnt = index;
					sec4MainslideFn();
					touchTimeControlFn();
				}
			});
		});
		
		function pageNationFn(){
			$('.s4PageBt').removeClass('addCurrentPage');
			$('.s4PageBt').eq(s4cnt).addClass('addCurrentPage');
		}
		
		function sec4MainslideFn(){
			$('.sec4Slide-wrap').stop().animate({left:(-s4slideW*s4cnt)},800, function(){
				if( s4cnt > n ){
					s4cnt = 0;
				}
				if( s4cnt  < 0 ){
					s4cnt = n;
				}
				$('.sec4Slide-wrap').stop().animate({left:(-s4slideW*s4cnt)},0);
			});
			s4cnt>2?s4cnt=0:s4cnt;
			pageNationFn();
		}
		
		
	
})( jQuery, window, document);