;(function($, window, document, undefined){ //즉시실행함수(IIFE)
	var chk;
	var cookieValue;
		
		//4.쿠키 가져오기 - 어디에서 openPoupupFn() 팝업창 띄울때
		function getCookieFn(name){
			var found = false; //토글변수
			var start;
			var end;
			var n = document.cookie.length;
					
				//쿠키정보와 가져온 팝업창 쿠키이름과 비교
				for(i=0; i<n; i++){
					start = i;
					end = start + name.length;
					
					// console.log('start ' + start );
					// console.log('end '   + end );
					
					if( document.cookie.slice(start, end) == name  ){
					// if( document.cookie.substring(start, end) == name  ){
						found = true;
						alert('찾았음');
						break;
					}
				}  //반복문 종료
				
				
				
				//쿠키 정보와 쿠키 이름 비교해서 찾으면 변수 found = true  설정
				//쿠키에 해당하는 value값을 뽑아낸다.
				if( found === true ){ 
					start = end + 1;  //14
					end = document.cookie.indexOf(';', start);  //-1
					
					if( start > end ){
						end = document.cookie.length;
						//쿠키 valuer값 뽑는다.
						cookieValue = document.cookie.slice(start, end);
						// cookieValue = document.cookie.substring(start, end);
					}
					else{ //여러개 쿠키 정보에서 밸류값 추출(뽑아낸다) 
						cookieValue = document.cookie.slice(start, end);
					}
					
				}
			
		}
	
		//3.쿠키 설정
		//날짜객체 가져오기 new Date();  
		//오늘날짜 가져오기 getFullYear();년도 getDate();날짜 getTime();시간 getDay();요일 			
		function setCookieFn( name, value, expires ){
			var toDay = new Date();  //toGMTString  toUTCString 표준시 셋팅
				toDay.setDate( toDay.getDate() + expires ); //날짜계산 + 1 만료일 16+1=17일 
				// toDay.setTime( toDay.getTime() + (expires*24*60*60*1000) ); //날짜계산 + 1 만료일 16+1=17일 

				// var cookieStr =	 name + '=' + value + '; path=/; expires=' + toDay.toGMTString() + ';';                   //pop20200316_1=no; path=/; expires=toGMTString;
			var cookieStr =	 name + '=' + value + '; path=/; expires=' + toDay.toUTCString() + ';';                   //pop20200316_1=no; path=/; expires=toUTCString;
				document.cookie = cookieStr;  //쿠키 설정
				
		}

		//2.팝업창 열기
		//홈페이지가 로딩시 팝업창 열기
		openPoupupFn();
		function openPoupupFn(){
			getCookieFn('theMOONJONG');
			if( cookieValue != 'no'  ){  //하루동안 열지 않음 체크시 value값이 no가 아니면
				if( $(window).innerWidth() > 1024 ){
					$('#popup').stop().show();	
				}
			}
		}
		
		//1.팝업창 닫기
		// $('#chkbox').prop('checked', true );  //초기설정 체크 설정 true
		// $('#chkbox').prop('checked', false ); //초기설정 체크 해제 false	
		$('.popupCloseBt').on({
			click:	function(){
				// var chk = $('#chkbox').is(':checked');
				chk = $('#chkbox').prop('checked');  //체크박스 상태 확인 true or false
				
				//체크박스가 선택 되면 true 이면 쿠키 설정 한다.
				if( chk === true ){
					//쿠키설정 함수 setCookieFn() 매개변수 전달
					// setCookieFn( name, value, expires );
					setCookieFn('theMOONJONG', 'no', 1 );  //쿠키함수 호출 설정 한다.
				}
				$('#popup').stop().hide();
			}
		});
		
		
})(jQuery, window, document);